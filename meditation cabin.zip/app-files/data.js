var APP_DATA = {
  "scenes": [
    {
      "id": "0-panorama_3d_views-655878-rhinoautosave_2022-04-05-13-26-53",
      "name": "Panorama_3d_views (655878) RhinoAutosave_2022-04-05-13-26-53",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [
        {
          "yaw": 0.16751346286968527,
          "pitch": 0.036718592871922695,
          "rotation": 0,
          "target": "1-panorama_3d_views-655878-rhinoautosave_2022-04-05-13-34-34"
        }
      ],
      "infoHotspots": []
    },
    {
      "id": "1-panorama_3d_views-655878-rhinoautosave_2022-04-05-13-34-34",
      "name": "Panorama_3d_views (655878) RhinoAutosave_2022-04-05-13-34-34",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "pitch": 0,
        "yaw": 0,
        "fov": 1.5707963267948966
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "Project Title",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": true,
    "fullscreenButton": false,
    "viewControlButtons": false
  }
};
